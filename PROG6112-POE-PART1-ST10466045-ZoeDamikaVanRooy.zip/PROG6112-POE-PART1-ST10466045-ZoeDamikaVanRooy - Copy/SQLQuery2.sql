/* ============================================================
   RACE DAY SYSTEM
   PART 1 - SECTION C: SQL DATABASE SCRIPT
   SQL Server / SSMS
   ============================================================ */

-- Create Database
IF DB_ID('RaceDayDB') IS NOT NULL
BEGIN
    ALTER DATABASE RaceDayDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE RaceDayDB;
END;
GO

CREATE DATABASE RaceDayDB;
GO

USE RaceDayDB;
GO

/* ============================================================
   1. USERS
   ============================================================ */

CREATE TABLE Users
(
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    Email NVARCHAR(100) NOT NULL UNIQUE,
    PasswordHash NVARCHAR(255) NOT NULL,
    PhoneNumber NVARCHAR(20) NULL,
    Role NVARCHAR(20) NOT NULL
        CONSTRAINT CK_Users_Role CHECK (Role IN ('Organiser', 'Participant')),
    CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE()
);
GO

/* ============================================================
   2. ORGANISERS
   ============================================================ */

CREATE TABLE Organisers
(
    OrganiserID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT NOT NULL UNIQUE,
    OrganisationName NVARCHAR(100) NOT NULL,

    CONSTRAINT FK_Organisers_Users
        FOREIGN KEY (UserID)
        REFERENCES Users(UserID)
);
GO

/* ============================================================
   3. PARTICIPANTS
   ============================================================ */

CREATE TABLE Participants
(
    ParticipantID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT NOT NULL UNIQUE,
    EmergencyContactName NVARCHAR(100) NULL,
    EmergencyContactPhone NVARCHAR(20) NULL,

    CONSTRAINT FK_Participants_Users
        FOREIGN KEY (UserID)
        REFERENCES Users(UserID)
);
GO

/* ============================================================
   4. EVENTS
   ============================================================ */

CREATE TABLE Events
(
    EventID INT IDENTITY(1,1) PRIMARY KEY,
    OrganiserID INT NOT NULL,
    EventName NVARCHAR(150) NOT NULL,
    Description NVARCHAR(500) NULL,
    EventDate DATE NOT NULL,
    StartTime TIME NOT NULL,
    Location NVARCHAR(200) NOT NULL,
    MaximumParticipants INT NOT NULL DEFAULT 100,
    EntryFee DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    Status NVARCHAR(20) NOT NULL DEFAULT 'Upcoming',

    CONSTRAINT CK_Events_MaxParticipants
        CHECK (MaximumParticipants > 0),

    CONSTRAINT CK_Events_EntryFee
        CHECK (EntryFee >= 0),

    CONSTRAINT CK_Events_Status
        CHECK (Status IN ('Upcoming', 'Open', 'Closed', 'Completed', 'Cancelled')),

    CONSTRAINT FK_Events_Organisers
        FOREIGN KEY (OrganiserID)
        REFERENCES Organisers(OrganiserID)
);
GO

/* ============================================================
   5. CATEGORIES
   ============================================================ */

CREATE TABLE Categories
(
    CategoryID INT IDENTITY(1,1) PRIMARY KEY,
    EventID INT NOT NULL,
    CategoryName NVARCHAR(100) NOT NULL,
    MinimumAge INT NOT NULL,
    MaximumAge INT NULL,
    DistanceKM DECIMAL(5,2) NOT NULL,

    CONSTRAINT CK_Categories_MinimumAge
        CHECK (MinimumAge >= 0),

    CONSTRAINT CK_Categories_MaximumAge
        CHECK (MaximumAge IS NULL OR MaximumAge >= MinimumAge),

    CONSTRAINT CK_Categories_Distance
        CHECK (DistanceKM > 0),

    CONSTRAINT UQ_Categories_Event_Category
        UNIQUE (EventID, CategoryName),

    CONSTRAINT FK_Categories_Events
        FOREIGN KEY (EventID)
        REFERENCES Events(EventID)
        ON DELETE CASCADE
);
GO

/* ============================================================
   6. EVENT ENROLMENTS
   ============================================================ */

CREATE TABLE EventEnrolments
(
    EnrolmentID INT IDENTITY(1,1) PRIMARY KEY,
    ParticipantID INT NOT NULL,
    EventID INT NOT NULL,
    CategoryID INT NOT NULL,
    EnrolmentDate DATETIME2 NOT NULL DEFAULT GETDATE(),
    EnrolmentStatus NVARCHAR(20) NOT NULL DEFAULT 'Registered',

    CONSTRAINT CK_Enrolments_Status
        CHECK (EnrolmentStatus IN ('Registered', 'Confirmed', 'Cancelled')),

    CONSTRAINT UQ_Enrolment_Participant_Event
        UNIQUE (ParticipantID, EventID),

    CONSTRAINT FK_Enrolments_Participants
        FOREIGN KEY (ParticipantID)
        REFERENCES Participants(ParticipantID),

    CONSTRAINT FK_Enrolments_Events
        FOREIGN KEY (EventID)
        REFERENCES Events(EventID),

    CONSTRAINT FK_Enrolments_Categories
        FOREIGN KEY (CategoryID)
        REFERENCES Categories(CategoryID)
);
GO

/* ============================================================
   7. RESULTS
   ============================================================ */

CREATE TABLE Results
(
    ResultID INT IDENTITY(1,1) PRIMARY KEY,
    EnrolmentID INT NOT NULL UNIQUE,
    FinishPosition INT NULL,
    FinishTime TIME NULL,
    ResultStatus NVARCHAR(20) NOT NULL DEFAULT 'Finished',
    RecordedAt DATETIME2 NOT NULL DEFAULT GETDATE(),

    CONSTRAINT CK_Results_Position
        CHECK (FinishPosition IS NULL OR FinishPosition > 0),

    CONSTRAINT CK_Results_Status
        CHECK (ResultStatus IN ('Finished', 'DNF', 'DNS', 'Disqualified')),

    CONSTRAINT FK_Results_Enrolments
        FOREIGN KEY (EnrolmentID)
        REFERENCES EventEnrolments(EnrolmentID)
        ON DELETE CASCADE
);
GO

/* ============================================================
   INSERT SAMPLE USERS
   Minimum: 2 Organisers + 2 Participants
   ============================================================ */

INSERT INTO Users
(
    FirstName,
    LastName,
    Email,
    PasswordHash,
    PhoneNumber,
    Role
)
VALUES
(
    'Thabo',
    'Mokoena',
    'thabo@raceday.co.za',
    'hashed_password_123',
    '0821112233',
    'Organiser'
),
(
    'Lerato',
    'Nkosi',
    'lerato@raceday.co.za',
    'hashed_password_456',
    '0832223344',
    'Organiser'
),
(
    'Zoe',
    'Williams',
    'zoe@email.com',
    'hashed_password_789',
    '0711112233',
    'Participant'
),
(
    'Daniel',
    'Smith',
    'daniel@email.com',
    'hashed_password_101',
    '0722223344',
    'Participant'
);
GO

/* ============================================================
   INSERT ORGANISERS
   ============================================================ */

INSERT INTO Organisers
(
    UserID,
    OrganisationName
)
VALUES
(
    1,
    'RaceDay Events'
),
(
    2,
    'Limpopo Running Club'
);
GO

/* ============================================================
   INSERT PARTICIPANTS
   ============================================================ */

INSERT INTO Participants
(
    UserID,
    EmergencyContactName,
    EmergencyContactPhone
)
VALUES
(
    3,
    'Sarah Williams',
    '0733334455'
),
(
    4,
    'Michael Smith',
    '0744445566'
);
GO

/* ============================================================
   INSERT EVENTS
   ============================================================ */

INSERT INTO Events
(
    OrganiserID,
    EventName,
    Description,
    EventDate,
    StartTime,
    Location,
    MaximumParticipants,
    EntryFee,
    Status
)
VALUES
(
    1,
    'Cape Town City Run',
    'Annual city road running event.',
    '2026-10-10',
    '07:00:00',
    'Cape Town',
    500,
    250.00,
    'Open'
),
(
    1,
    'Limpopo Fun Run',
    'Community fun run for all ages.',
    '2026-11-15',
    '08:00:00',
    'Polokwane',
    300,
    150.00,
    'Open'
),
(
    2,
    'Summer Marathon',
    'Long-distance summer road race.',
    '2026-12-05',
    '06:00:00',
    'Johannesburg',
    1000,
    350.00,
    'Upcoming'
);
GO

/* ============================================================
   INSERT CATEGORIES
   Categories for EACH event
   ============================================================ */

INSERT INTO Categories
(
    EventID,
    CategoryName,
    MinimumAge,
    MaximumAge,
    DistanceKM
)
VALUES
-- Cape Town City Run
(
    1,
    '5 KM Fun Run',
    13,
    NULL,
    5.00
),
(
    1,
    '10 KM Race',
    16,
    NULL,
    10.00
),
(
    1,
    '21 KM Half Marathon',
    18,
    NULL,
    21.10
),

-- Limpopo Fun Run
(
    2,
    '5 KM Junior Run',
    10,
    17,
    5.00
),
(
    2,
    '10 KM Adult Run',
    18,
    NULL,
    10.00
),

-- Summer Marathon
(
    3,
    '10 KM Challenge',
    16,
    NULL,
    10.00
),
(
    3,
    '21 KM Half Marathon',
    18,
    NULL,
    21.10
),
(
    3,
    '42 KM Marathon',
    18,
    NULL,
    42.20
);
GO

/* ============================================================
   INSERT EVENT ENROLMENTS
   ============================================================ */

INSERT INTO EventEnrolments
(
    ParticipantID,
    EventID,
    CategoryID,
    EnrolmentStatus
)
VALUES
(
    1,
    1,
    1,
    'Confirmed'
),
(
    2,
    1,
    2,
    'Confirmed'
),
(
    1,
    2,
    5,
    'Registered'
),
(
    2,
    3,
    7,
    'Registered'
);
GO

/* ============================================================
   INSERT RESULTS
   ============================================================ */

INSERT INTO Results
(
    EnrolmentID,
    FinishPosition,
    FinishTime,
    ResultStatus
)
VALUES
(
    1,
    1,
    '00:28:35',
    'Finished'
),
(
    2,
    2,
    '00:52:18',
    'Finished'
);
GO

/* ============================================================
   TEST / DISPLAY DATA
   ============================================================ */

SELECT * FROM Users;
SELECT * FROM Organisers;
SELECT * FROM Participants;
SELECT * FROM Events;
SELECT * FROM Categories;
SELECT * FROM EventEnrolments;
SELECT * FROM Results;
GO

/* ============================================================
   END OF RACE DAY DATABASE SCRIPT
   ============================================================ */